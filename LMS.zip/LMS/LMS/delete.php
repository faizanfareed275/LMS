<?php
include 'db.php';
$id = $_GET['id']; // superGlobal Array used to collect data sent via the URL query string 
$conn->query("DELETE FROM books WHERE id=$id");
header("Location: index.php"); // Redirects the user to index.php after the deletion is performed
?>
