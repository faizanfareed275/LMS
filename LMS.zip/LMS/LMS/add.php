<?php
include 'db.php';

// The if (isset($_POST['submit'])) line checks if the form has been submitted by the user.
// It is used to ensure that the code inside the if block only runs when the form has actually been submitted and not when the page is just being loaded.

if (isset($_POST['submit'])) { // isset() is a PHP function that checks if a variable is set and is not null.
    $title = $_POST['title'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $availability = $_POST['availability'];
    
    $conn->query("INSERT INTO books (title, author, genre, availability) 
                  VALUES ('$title', '$author', '$genre', '$availability')");
    header("Location: index.php");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="header">
    <h2 class="libHeading">Library Management System</h2>
    <h2><a href="../LoginAndSignup/login.php" <?php
$cookie_name = 'password';
$cookie_name1 = 'email';
$cookie_session = 'PHPSESSID';

// empty value and expiration one hour before
 setcookie($cookie_name,'', time() - 3600,'/');
 setcookie($cookie_name1,'', time() - 3600,'/');
 setcookie($cookie_session,'', time() - 3600,'/');
?> >Logout</a> </h2>

    </div>
    <hr>

    <section class="editPage">

        <div>

            <h2 class="editBookHeading">Add New Book</h2>
            <form  class="editForm" method="POST">
                Title: <input type="text" name="title" required><br>
                Author: <input type="text" name="author" required><br>
                Genre: <input type="text" name="genre" required><br>
                Availability:
                <select name="availability">
                    <option value="Available">Available</option>
                    <option value="Not Available">Not Available</option>
                </select><br>
                <button type="submit" name="submit">Add Book</button>
            </form>

        </div>

    </section>


</body>

</html>