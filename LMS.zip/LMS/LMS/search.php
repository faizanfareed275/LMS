<?php
include 'db.php';

// Check if 'query' is provided in the URL
if (isset($_GET['query'])) {
    $search = $_GET['query'];
    // Prevent SQL injection by escaping special characters
    $search = $conn->real_escape_string($search);

    // Query to search in 'title' and 'author' columns
    $result = $conn->query("SELECT * FROM books WHERE title LIKE '%$search%' OR author LIKE '%$search%'");
} else {
    // Redirect back to the index page if no query is provided
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>search</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="header">
    <h2 class="libHeading">Library Management System</h2>
    <h2><a href="../LoginAndSignup/login.php" <?php
$cookie_name = 'password';
$cookie_name1 = 'email';
$cookie_session = 'PHPSESSID';

// empty value and expiration one hour before
 setcookie($cookie_name,'', time() - 3600,'/');
 setcookie($cookie_name1,'', time() - 3600,'/');
 setcookie($cookie_session,'', time() - 3600,'/');
?> >Logout</a> </h2>

    </div>
    <h2 class="searchResultHeading">Search Results</h2>
<a href="index.php" class="bToBList">Back to Book List</a>

<section class="table">

    <?php if ($result->num_rows > 0): ?>
<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>Genre (Category)</th>
        <th>Availability</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['title'] ?></td>
        <td><?= $row['author'] ?></td>
        <td><?= $row['genre'] ?></td>
        <td><?= $row['availability'] ?></td>
        <td>
            <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
            <a class="deleteBtn" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php } ?>

</table>

</section>
<?php else: ?>
    <p class="bookNotFound">No books found matching your search.</p>
<?php endif; ?>

    
</body>
</html>

