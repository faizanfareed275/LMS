<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM books WHERE id=$id");
$row = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $availability = $_POST['availability'];

    $conn->query("UPDATE books SET title='$title', author='$author', genre='$genre', availability='$availability' WHERE id=$id");
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="header">
        <h2 class="libHeading">Library Management System</h2>
        <h2><a href="../LoginAndSignup/login.php" <?php
$cookie_name = 'password';
$cookie_name1 = 'email';
$cookie_session = 'PHPSESSID';

// empty value and expiration one hour before
 setcookie($cookie_name,'', time() - 3600,'/');
 setcookie($cookie_name1,'', time() - 3600,'/');
 setcookie($cookie_session,'', time() - 3600,'/');
?> >Logout</a> </h2>
    
        </div>
            <hr>

    <section class="editPage">

        <div>

            <h2 class="editBookHeading">Edit Book</h2>
            <form class="editForm" method="POST">
                Title: <input type="text" name="title" value="<?= $row['title'] ?>" required><br>
                Author: <input type="text" name="author" value="<?= $row['author'] ?>" required><br>
                Genre: <input type="text" name="genre" value="<?= $row['genre'] ?>" required><br>
                Availability:
                <select name="availability">
                    <option value="Available" <?=$row['availability']=='Available' ? 'selected' : '' ?>>Available
                    </option>
                    <option value="Not Available" <?=$row['availability']=='Not Available' ? 'selected' : '' ?>>Not
                        Available</option>
                </select><br>
                <button type="submit" name="update">Update Book</button>
            </form>

        </div>

    </section>



</body>

</html>