
-- Create a MySQL database named "library_system" and a table "books":

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    availability VARCHAR(50) DEFAULT 'Available'
);
