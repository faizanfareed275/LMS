<?php
include 'db.php';
$result = $conn->query("SELECT * FROM books"); // query() is a method of the mysqli class that sends a SQL query to the MySQL server.
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="header">
        <h2 class="libHeading">Library Management System</h2>
        <h2><a href="../LoginAndSignup/login.php" <?php
$cookie_name = 'password';
$cookie_name1 = 'email';
$cookie_session = 'PHPSESSID';

// empty value and expiration one hour before
 setcookie($cookie_name,'', time() - 3600,'/');
 setcookie($cookie_name1,'', time() - 3600,'/');
 setcookie($cookie_session,'', time() - 3600,'/');
?> >Logout</a> </h2>
    
        </div>
    
    <hr>
    <form method="GET" action="search.php">
        <input type="text" name="query" placeholder="Search books by title or author" required>
        <button type="submit">Search</button>
    </form>

    <div class="newBook">
        <a href="add.php">Add New Book</a>
    </div>

    <section class="table">

        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Genre (Category)</th>
                <th>Availability</th>
                <th>Actions</th>
            </tr>

            <!-- fetch_assoc() is a method Associative array  -->
            <!-- ?> we use this to switch back from php mode to plain html mode. It tells the PHP interpreter to stop processing PHP and start treating the rest as HTML. -->
            <?php while ($row = $result->fetch_assoc()) { ?> 
            <tr>
                <td>
                    <?= $row['id'] ?> 
                </td>
                <td>
                    <?= $row['title'] ?>
                </td>
                <td>
                    <?= $row['author'] ?>
                </td>
                <td>
                    <?= $row['genre'] ?>
                </td>
                <td>
                    <?= $row['availability'] ?>
                </td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
                    <a class="deleteBtn" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a> 
                </td>
            </tr>
            <?php } ?>
        </table>

      
       

    </section>
    


</body>

</html>


 <!-- JS onclick function for popup in deleteBtn class  -->