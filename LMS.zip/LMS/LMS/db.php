<?php

// connecting Database
$Servername = 'localhost'; // database server and webserver hosted on the same machine
$Username = 'root';     // default MySQl user in local Environment
$Password = '';
$Database = 'LMS';

// create connection
$conn = new mysqli($Servername, $Username, $Password, $Database); // "mysqli" built-in class in PHP and here msqli constructor (in this case having 4 parameters) used to interact with databases and new keyword will create new instance
// $conn is the object of mysqli class

if($conn->connect_error){ // connect_error is the attribute of the object $conn (work same as if we create new instance and store the address in pointer to access this we use -> operator istead of writng (*P).attributeName ).
    die("Connection Failed!" . $conn->connect_error);
}
// echo("Connected.");
?>