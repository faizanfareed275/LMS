<?php

$databaseHost = 'localhost';
$databaseName = 'LMS';
$databaseUsername = 'root';
$databasePassword = ''; 

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

if($mysqli->connect_error){
    die("connection failed" .$mysqli->connect_error);
}
else{
    echo ("connection Established");
}
 
?>
