<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LBM</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section class="Lib">
        <div class="mainHeading">
            <h1>Libray Management System</h1>
        </div>
        <div class="dis">
            <p>Empowering Knowledge, Simplifying Management</p>
        </div>

        <div class="button">
            <div class="login">
                <button><a href="LoginAndSignup/login.php">Login</a></button>
            </div>
            <div class="signup">
                <button><a href="LoginAndSignup/signup.php">Signup</a></button>
            </div>
        </div>

    </section>

</body>

</html>